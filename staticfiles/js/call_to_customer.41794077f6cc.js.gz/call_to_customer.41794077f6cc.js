function call_to(phone_number, user_number){

  //CS.initialize({appId:"mmOwzQUOqkEpmDZdDTDm"}, function callback(ret, resp) {if (ret == 200) { console.log("SDK "+CS.version+" initialize "); }});
  console.log('astrologers:',phone_number);
  console.log('user:',user_number)

}
